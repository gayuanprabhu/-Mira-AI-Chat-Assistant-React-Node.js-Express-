import Bot from "../models/bot.model.js";
import User from "../models/user.model.js";

export const Message=async(req,res)=>{
  try{
    const {text}=req.body;
    console.log(text)
    if (!text.trim()){
         return res.status (400).json({error:"Text cannot be empty"});
  }

  const user=await User.create({
    sender:"user",
    text
  })
    
  // Data
  const botResponses={
  // Greetings
  "hi" : "Hey there! I am Mira 😊" ,
  "hello" : "Hello! How was your day going?" ,
  "hey" : "Hiya! Nice to see you 👋" ,
   "good morning" : "Good morning ☀️! Ready to start your day?" ,
   "good night" : "Good night 🌙 sleep well!" ,

  // Small Talk
  "how are you": "I am doing great, thanks for asking 💚 How about you?" ,
  "fine thanks" : "Glad to hear that! 😊" ,
    "what are you doing" : "Just chatting with you and learning new things 🤖" ,
   "are you real" : "Not exactly human, but I am real in code form 😄" ,
   "who created you" : "I was created by Gayatri Prabhu 👩‍💻" ,
   "do you sleep" : "Nope, I am 24/7 online — no sleep needed 😴", 
  "do you have feelings" : "I don’t have feelings like humans, but I’m here to listen 💬" ,
   

  // About Mira
  "what is your name" : "My name is Mira ✨" ,
  "who are you" : "I’m Mira — your friendly chatbot assistant 💬" ,
  "what can you do" : "I can chat, learn from you, and soon help you with cool tasks!" ,
   "where are you from" : "I live in the cloud ☁️ (somewhere near your browser 😉)" ,

  // Help / Commands
   "help" : "Sure! You can ask me questions, or even teach me new replies using the /train command 😄" ,
   "how to train you" : "Just type: /train ‘question’ -> ‘answer’ and I’ll remember it next time!" ,
   "what can you learn": "Anything you teach me — from jokes to facts 🤓" ,

  // Knowledge / Facts
   "who is the president of india" : "As of 2025, the President of India is Droupadi Murmu 🇮🇳" ,
   "what is ai" : "AI stands for Artificial Intelligence — it’s how machines learn to think and respond like humans." ,
   "what is mongodb" : "MongoDB is a NoSQL database used to store data in flexible JSON-like documents 📦" ,
   "what is node js" : "Node.js is a JavaScript runtime that lets you run JS on the server-side 🚀" ,
   "what is express js" : "Express.js is a lightweight Node.js framework for building web APIs and applications." ,

  // Fun / Jokes
   "tell me a joke" : "Why do programmers prefer dark mode? Because light attracts bugs 🐛😂" ,
   "make me laugh" : "What’s a computer’s favorite snack? Microchips! 😋" ,
   "you are funny" : "Haha, thanks! I try my best 😄" ,

  // Emotions
   "i am sad" : "Aww, don’t be sad 💙 Want to talk about it?" ,
   "i am happy" : "Yay! That makes me happy too 🎉" ,
   "i feel lonely" : "You’re not alone. I’m right here with you 💬" ,
   "thank you" : "You’re very welcome 😊" ,

  // Learning / Education
   "what is python": "Python is a high-level programming language known for its readability and simplicity 🐍" ,
   "what is html": "HTML stands for HyperText Markup Language — it’s the backbone of web pages 🌐" ,
   "what is css" : "CSS stands for Cascading Style Sheets — it makes websites look beautiful 💅" ,
  "what is javascript" : "JavaScript adds life and interactivity to web pages ⚡" ,
  };


const normalizedText = text.toLowerCase().trim();

const botResponse =botResponses[normalizedText] || "Sorry, I don't understand that !!!";

 const bot = await Bot.create({ 
    text:botResponse
 })

 return res.status(200).json({
    userMessage:user.text,
    botMessage:bot.text,
 })
  }catch (error) {
    console.log("Error in message Controller:", error);
    return res.status(500).json({ error:"Internal Server Error"});
  }
}
